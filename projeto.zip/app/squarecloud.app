DISPLAY_NAME=Gabriel Termo API
DESCRIPTION=Trabalho de API REST do Gabriel
MAIN=server.php
MEMORY=512
VERSION=recommended
SUBDOMAIN=gabrieltavares-termoo