<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Jogo extends Model
{
    use HasFactory;

    // 1. Avisamos que o ID NÃO é um número automático
    public $incrementing = false;
    
    // 2. Avisamos que o tipo do ID é uma string (texto)
    protected $keyType = 'string';

    // 3. Liberamos as colunas que podemos preencher pelo código
    protected $fillable = [
        'id',
        'palavra_secreta',
        'tentativas_restantes'
    ];
}