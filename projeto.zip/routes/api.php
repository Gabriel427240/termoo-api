<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, Accept');

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\jogoController;

// Rota 1: Iniciar o Jogo
Route::post('/iniciar-jogo', [jogoController::class, 'iniciarJogo']);

// Rota 2: Validar a Tentativa
Route::post('/validar-tentativa', [jogoController::class, 'validarTentativa']);